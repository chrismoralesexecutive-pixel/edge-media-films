# Edge Media Films — Landing Page

React + Vite + TypeScript + Tailwind CSS + Framer Motion. Two full-screen
sections (Hero, Capabilities) with "liquid glass" UI and word-by-word
blur-in text reveals.

## Run it

```bash
npm install
npm run dev
```

## Adding your own footage

`FadingVideo` looks for clips at:

- `public/videos/hero-reel.mp4`
- `public/videos/capabilities-reel.mp4`

Drop your own footage in with those exact names (or pass an array of
paths to `<FadingVideo src={[...]} />` to cycle through several clips).
Until real footage is in place, each section falls back to a quiet
gradient (`.footage-fallback` in `src/index.css`) so the page still
reads as intentional.

## Structure

```
src/
  components/
    FadingVideo.tsx   — background video player (fade in/out, loop or cycle)
    BlurText.tsx      — word-by-word blur-in reveal on scroll
    icons.tsx         — custom SVG icon set (camera, clapperboard, etc.)
  sections/
    Hero.tsx
    Capabilities.tsx
  index.css           — .liquid-glass / .liquid-glass-strong tokens
```

## Content pass

Copy, stats, and client names are placeholders — swap in your real
numbers, client roster, and service language before shipping.
