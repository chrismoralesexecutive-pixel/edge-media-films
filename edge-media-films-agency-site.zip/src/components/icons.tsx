// Custom, hand-drawn SVG icon set for Edge Media Films.
// Kept intentionally simple/geometric so they sit quietly inside
// the liquid-glass chrome rather than competing with it.

export function ArrowUpRight({ className }: { className?: string }) {
  return (
    <svg className={className} width="24" height="24" viewBox="0 0 24 24" fill="none">
      <path d="M7 17L17 7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M7 7h10v10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export function PlayIcon({ className }: { className?: string }) {
  return (
    <svg className={className} width="24" height="24" viewBox="0 0 24 24" fill="none">
      <polygon points="6 4 20 12 6 20 6 4" fill="currentColor" />
    </svg>
  )
}

export function ClockIcon({ className }: { className?: string }) {
  return (
    <svg className={className} width="24" height="24" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.5" />
      <path d="M12 7v5l3 2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export function GlobeIcon({ className }: { className?: string }) {
  return (
    <svg className={className} width="24" height="24" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.5" />
      <path d="M3 12h18" stroke="currentColor" strokeWidth="1.5" />
      <path d="M12 3c2.8 2.4 4.5 5.6 4.5 9s-1.7 6.6-4.5 9" stroke="currentColor" strokeWidth="1.5" fill="none" />
      <path d="M12 3c-2.8 2.4-4.5 5.6-4.5 9s1.7 6.6 4.5 9" stroke="currentColor" strokeWidth="1.5" fill="none" />
    </svg>
  )
}

/** Cinematography — camera body with lens and aperture blades */
export function CameraIcon({ className }: { className?: string }) {
  return (
    <svg className={className} width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
      <path d="M4 8a2 2 0 0 1 2-2h1.5l1-1.5h7l1 1.5H18a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8Z" />
      <circle cx="12" cy="13" r="3.4" fill="#000" />
      <circle cx="12" cy="13" r="2.1" fill="currentColor" />
    </svg>
  )
}

/** Post & VFX — film clapperboard */
export function ClapperIcon({ className }: { className?: string }) {
  return (
    <svg className={className} width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
      <path d="M3 10h18v9a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 19v-9Z" />
      <path d="M3.6 9 4.4 5.2 7.9 6l-1 3.8-3.3-.8Z" />
      <path d="M8.6 9.6 9.4 5.8l3.5.8-1 3.8-3.3-.8Z" />
      <path d="M13.6 10.2 14.4 6.4l3.5.8-1 3.8-3.3-.8Z" />
    </svg>
  )
}

/** Strategy & distribution — idea / broadcast bulb */
export function LightbulbIcon({ className }: { className?: string }) {
  return (
    <svg className={className} width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 2a6.5 6.5 0 0 0-4 11.6c.7.6 1.1 1.4 1.1 2.3V17h5.8v-1.1c0-.9.4-1.7 1.1-2.3A6.5 6.5 0 0 0 12 2Z" />
      <rect x="9.1" y="18.5" width="5.8" height="1.6" rx="0.6" />
      <rect x="9.7" y="21" width="4.6" height="1.4" rx="0.6" />
    </svg>
  )
}
