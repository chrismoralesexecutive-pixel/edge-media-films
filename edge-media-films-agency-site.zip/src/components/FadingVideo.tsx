import { useEffect, useRef, useState, type CSSProperties } from 'react'

interface FadingVideoProps {
  src: string | string[]
  className?: string
  style?: CSSProperties
}

/**
 * Background footage player for Edge Media Films.
 * Fades in once a clip has data, fades out just before it ends,
 * then either loops (single source) or advances to the next reel
 * in the array. If the source 404s (no footage dropped in yet),
 * it simply stays transparent and the .footage-fallback gradient
 * behind it carries the section.
 */
export default function FadingVideo({ src, className, style }: FadingVideoProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [index, setIndex] = useState(0)
  const [opacity, setOpacity] = useState(0)
  const sources = Array.isArray(src) ? src : [src]

  const fade = (from: number, to: number, duration: number) => {
    const start = performance.now()
    const step = (now: number) => {
      const t = Math.min(1, (now - start) / duration)
      setOpacity(from + (to - from) * t)
      if (t < 1) requestAnimationFrame(step)
    }
    requestAnimationFrame(step)
  }

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    const handleLoaded = () => fade(0, 1, 500)

    const handleTimeUpdate = () => {
      if (!video.duration) return
      const remaining = video.duration - video.currentTime
      if (remaining <= 0.55 && remaining > 0) {
        fade(opacity, 0, 550)
      }
    }

    const handleEnded = () => {
      if (sources.length === 1) {
        video.currentTime = 0
        video.play().catch(() => {})
        fade(0, 1, 500)
      } else {
        setIndex((i) => (i + 1) % sources.length)
      }
    }

    video.addEventListener('loadeddata', handleLoaded)
    video.addEventListener('timeupdate', handleTimeUpdate)
    video.addEventListener('ended', handleEnded)

    return () => {
      video.removeEventListener('loadeddata', handleLoaded)
      video.removeEventListener('timeupdate', handleTimeUpdate)
      video.removeEventListener('ended', handleEnded)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index])

  return (
    <video
      key={sources[index]}
      ref={videoRef}
      className={className}
      style={{ opacity, transition: 'opacity 0.1s linear', ...style }}
      src={sources[index]}
      autoPlay
      muted
      playsInline
      preload="auto"
    />
  )
}
