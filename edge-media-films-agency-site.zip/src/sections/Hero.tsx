import { motion } from 'framer-motion'
import FadingVideo from '../components/FadingVideo'
import BlurText from '../components/BlurText'
import { ArrowUpRight, PlayIcon, ClockIcon, GlobeIcon } from '../components/icons'

const navLinks = ['Work', 'Studio', 'Services', 'Journal', 'Contact']
const clientNames = ['Northline', 'Tidewater', 'Aftershock', 'Skyline', 'Meridian']

const fadeUp = {
  initial: { filter: 'blur(10px)', opacity: 0, y: 20 },
  animate: { filter: 'blur(0px)', opacity: 1, y: 0 },
}

export default function Hero() {
  return (
    <section className="relative h-screen overflow-hidden bg-black">
      {/* Footage backdrop */}
      <div className="footage-fallback" />
      <FadingVideo
        src="/videos/hero-reel.mp4"
        className="absolute left-1/2 top-0 z-0 -translate-x-1/2 object-cover object-top"
        style={{ width: '120%', height: '120%' }}
      />

      <div className="relative z-10 flex h-full flex-col">
        {/* Navbar */}
        <nav className="fixed left-0 right-0 top-4 z-50 flex items-center justify-between px-8 lg:px-16">
          <div className="liquid-glass flex h-12 w-12 items-center justify-center rounded-full">
            <span className="font-heading text-2xl italic">E</span>
          </div>

          <div className="liquid-glass hidden items-center gap-1 rounded-full px-1.5 py-1.5 md:flex">
            {navLinks.map((link) => (
              <a key={link} href="#" className="px-3 py-2 font-body text-sm font-medium text-white/90">
                {link}
              </a>
            ))}
            <a href="#contact" className="flex items-center gap-1 rounded-full bg-white px-4 py-2 text-sm font-medium text-black">
              Start a Project
              <ArrowUpRight className="h-3.5 w-3.5" />
            </a>
          </div>

          <div className="h-12 w-12" />
        </nav>

        {/* Main content */}
        <div className="flex flex-1 flex-col items-center justify-center px-4 pt-24 text-center">
          <motion.div
            {...fadeUp}
            transition={{ duration: 0.8, delay: 0.4, ease: 'easeOut' }}
            className="liquid-glass flex items-center gap-2 rounded-full px-4 py-2"
          >
            <span className="rounded-full bg-white px-2 py-0.5 text-[11px] font-medium text-black">New</span>
            <span className="font-body text-sm text-white/90">Booking Q3 2026 productions — limited slots</span>
          </motion.div>

          <div className="mt-6 max-w-3xl">
            <BlurText
              text="Cinematic Stories Built to Outlast the Scroll"
              className="font-heading text-6xl italic leading-[0.8] tracking-[-4px] text-white md:text-7xl lg:text-[5.5rem]"
            />
          </div>

          <motion.p
            {...fadeUp}
            transition={{ duration: 0.8, delay: 0.8, ease: 'easeOut' }}
            className="mt-4 max-w-2xl font-body text-sm font-light leading-tight text-white md:text-base"
          >
            We are a small studio of directors, DPs and editors shaping brand-defining films for
            ambitious companies. Precise craft, cinematic motion, and cuts you can be proud of.
          </motion.p>

          <motion.div
            {...fadeUp}
            transition={{ duration: 0.8, delay: 1.1, ease: 'easeOut' }}
            className="mt-6 flex items-center gap-6"
          >
            <a href="#contact" className="liquid-glass-strong flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-medium">
              Start a Project
              <ArrowUpRight className="h-4 w-4" />
            </a>
            <a href="#work" className="flex items-center gap-2 text-sm font-medium text-white">
              <PlayIcon className="h-4 w-4" />
              Watch Showreel
            </a>
          </motion.div>

          <motion.div
            {...fadeUp}
            transition={{ duration: 0.8, delay: 1.3, ease: 'easeOut' }}
            className="mt-8 flex gap-4"
          >
            <div className="liquid-glass w-[220px] rounded-[1.25rem] p-5 text-left">
              <ClockIcon className="h-5 w-5 text-white/80" />
              <div className="mt-4 font-heading text-4xl italic leading-none tracking-[-1px]">10 Days</div>
              <div className="mt-2 font-body text-xs text-white/70">Average Shoot-to-Delivery Turnaround</div>
            </div>
            <div className="liquid-glass w-[220px] rounded-[1.25rem] p-5 text-left">
              <GlobeIcon className="h-5 w-5 text-white/80" />
              <div className="mt-4 font-heading text-4xl italic leading-none tracking-[-1px]">120+</div>
              <div className="mt-2 font-body text-xs text-white/70">Productions Shot Across Four Continents</div>
            </div>
          </motion.div>
        </div>

        {/* Trust bar */}
        <motion.div
          {...fadeUp}
          transition={{ duration: 0.8, delay: 1.4, ease: 'easeOut' }}
          className="flex flex-col items-center gap-4 pb-8"
        >
          <div className="liquid-glass rounded-full px-4 py-2 font-body text-xs text-white/80">
            Trusted by founders, brand teams, and creative directors worldwide
          </div>
          <div className="flex gap-12 md:gap-16">
            {clientNames.map((name) => (
              <span key={name} className="font-heading text-2xl italic tracking-tight text-white/70 md:text-3xl">
                {name}
              </span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
