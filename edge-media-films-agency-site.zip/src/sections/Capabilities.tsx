import FadingVideo from '../components/FadingVideo'
import { CameraIcon, ClapperIcon, LightbulbIcon } from '../components/icons'

const cards = [
  {
    icon: CameraIcon,
    title: 'Cinematography',
    tags: ['Look Development', 'Lighting Design', 'Camera Direction', 'Color'],
    body: "We shape the visual language of every shoot — lighting, blocking, and lens choices that make a brand's world feel unmistakably its own, frame after frame.",
  },
  {
    icon: ClapperIcon,
    title: 'Post & VFX',
    tags: ['Editing', 'Color Grade', 'Sound Design', 'VFX'],
    body: 'Production-grade post pipelines built for broadcast and social. Cut with pacing that holds attention, graded and mixed by editors who stay on the project to the final export.',
  },
  {
    icon: LightbulbIcon,
    title: 'Strategy & Distribution',
    tags: ['Platform Cutdowns', 'Release Strategy', 'Analytics', 'Rights & Licensing'],
    body: 'Wrap is the starting line. We partner on cutdowns, platform edits, and release timing that turn one shoot into a season of content.',
  },
]

export default function Capabilities() {
  return (
    <section id="work" className="relative min-h-screen overflow-hidden bg-black">
      <div className="footage-fallback" />
      <FadingVideo src="/videos/capabilities-reel.mp4" className="absolute inset-0 z-0 h-full w-full object-cover" />

      <div className="relative z-10 flex min-h-screen flex-col px-8 pb-10 pt-24 md:px-16 lg:px-20">
        <div className="mb-auto">
          <div className="mb-6 font-body text-sm text-white/80">// Capabilities</div>
          <h2 className="font-heading text-6xl italic leading-[0.9] tracking-[-3px] md:text-7xl lg:text-[6rem]">
            Studio craft,
            <br />
            end to end
          </h2>
        </div>

        <div id="services" className="mt-16 grid grid-cols-1 gap-6 md:grid-cols-3">
          {cards.map(({ icon: Icon, title, tags, body }) => (
            <div key={title} className="liquid-glass flex min-h-[360px] flex-col rounded-[1.25rem] p-6">
              <div className="flex items-start justify-between gap-3">
                <div className="liquid-glass flex h-11 w-11 items-center justify-center rounded-[0.75rem]">
                  <Icon className="h-5 w-5 text-white" />
                </div>
                <div className="flex flex-wrap justify-end gap-1.5">
                  {tags.map((tag) => (
                    <span
                      key={tag}
                      className="liquid-glass whitespace-nowrap rounded-full px-3 py-1 font-body text-[11px] text-white/90"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex-1" />

              <div>
                <h3 className="font-heading text-3xl italic leading-none tracking-[-1px] md:text-4xl">{title}</h3>
                <p className="mt-3 max-w-[32ch] font-body text-sm font-light leading-snug text-white/90">{body}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
